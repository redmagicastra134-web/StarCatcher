package com.example.starcatcher;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.media.AudioManager;
import android.media.ToneGenerator;
import android.os.Vibrator;
import android.os.VibrationEffect;
import android.view.MotionEvent;
import android.view.View;
import java.util.*;

public class GameView extends View {
    Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    Random rnd = new Random();
    SharedPreferences prefs;
    ToneGenerator tone;
    Vibrator vibrator;
    float shipX, shipY;
    int score=0, lives=3, best=0;
    long last, spawnTimer;
    boolean playing=false, gameOver=false;
    ArrayList<Star> stars=new ArrayList<>(), sparks=new ArrayList<>(), bg=new ArrayList<>();

    static class Star { float x,y,r,v,a; Star(float x,float y,float r,float v){this.x=x;this.y=y;this.r=r;this.v=v;this.a=0;} }
    static class Spark { float x,y,vx,vy,life; Spark(float x,float y,float vx,float vy){this.x=x;this.y=y;this.vx=vx;this.vy=vy;life=1;} }

    public GameView(Context c) {
        super(c);
        prefs=c.getSharedPreferences("game",0);
        best=prefs.getInt("best",0);
        vibrator=(Vibrator)c.getSystemService(Context.VIBRATOR_SERVICE);
        try { tone=new ToneGenerator(AudioManager.STREAM_MUSIC,55); } catch(Exception ignored){}
        setFocusable(true);
    }

    void initBg() {
        if(!bg.isEmpty()) return;
        for(int i=0;i<110;i++) bg.add(new Star(rnd.nextFloat()*getWidth(),rnd.nextFloat()*getHeight(),
                .5f+rnd.nextFloat()*1.7f, 5+rnd.nextFloat()*18));
    }

    void startGame() {
        playing=true; gameOver=false; score=0; lives=3; stars.clear(); sparks.clear();
        shipX=getWidth()/2f; shipY=getHeight()-75; last=System.currentTimeMillis();
        spawnTimer=0; invalidate(); beep(660);
    }

    void finish() {
        playing=false; gameOver=true;
        if(score>best){best=score; prefs.edit().putInt("best",best).apply();}
        beep(180); vibrate(120);
        invalidate();
    }

    void beep(int hz) { if(tone!=null) try{tone.startTone(ToneGenerator.TONE_PROP_BEEP,70);}catch(Exception ignored){} }
    void vibrate(long ms) {
        try { if(vibrator!=null) vibrator.vibrate(VibrationEffect.createOneShot(ms,VibrationEffect.DEFAULT_AMPLITUDE)); } catch(Exception ignored){}
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c); initBg();
        float w=getWidth(), h=getHeight();
        LinearGradient g=new LinearGradient(0,0,0,h,Color.rgb(18,31,72),Color.rgb(1,3,12),Shader.TileMode.CLAMP);
        p.setShader(g); c.drawRect(0,0,w,h,p); p.setShader(null);
        for(Star s:bg){ s.y+=s.v/60f; if(s.y>h)s.y=0; p.setColor(Color.argb(120,220,232,255)); c.drawCircle(s.x,s.y,s.r,p); }
        for(Spark s:sparks){p.setAlpha((int)(255*s.life));p.setColor(Color.rgb(255,231,120));c.drawCircle(s.x,s.y,2.5f,p);} p.setAlpha(255);
        for(Star s:stars) drawStar(c,s.x,s.y,s.r);
        drawShip(c,shipX,shipY);

        p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(22); p.setColor(Color.WHITE);
        c.drawText("⭐ "+score,24,42,p);
        c.drawText("❤️ "+lives, w-105,42,p);
        p.setTextSize(14); p.setColor(Color.LTGRAY); c.drawText("Рекорд: "+best,24,65,p);

        if(!playing) drawMenu(c,w,h);
        else { postInvalidateDelayed(16); }
    }

    void drawMenu(Canvas c,float w,float h) {
        p.setColor(Color.argb(185,2,5,18)); c.drawRect(0,0,w,h,p);
        p.setTextAlign(Paint.Align.CENTER);
        p.setColor(Color.WHITE); p.setTypeface(Typeface.DEFAULT_BOLD); p.setTextSize(40);
        c.drawText(gameOver?"Игра окончена":"Лови звёзды",w/2,h/2-75,p);
        p.setTextSize(20); p.setColor(Color.rgb(190,205,235));
        c.drawText(gameOver?"Счёт: "+score+"   •   Рекорд: "+best:"Собирай звёзды и не теряй жизни!",w/2,h/2-35,p);
        p.setColor(Color.WHITE); c.drawRoundRect(w/2-115,h/2+5,w/2+115,h/2+65,18,18,p);
        p.setColor(Color.rgb(5,10,28)); p.setTextSize(19);
        c.drawText(gameOver?"ИГРАТЬ СНОВА":"НАЧАТЬ ИГРУ",w/2,h/2+43,p);
        p.setTextSize(13); p.setColor(Color.rgb(135,150,190));
        c.drawText("Двигай корабль пальцем",w/2,h/2+105,p);
        p.setTextAlign(Paint.Align.LEFT);
    }

    void drawStar(Canvas c,float x,float y,float r) {
        Path path=new Path();
        for(int i=0;i<10;i++){double a=-Math.PI/2+i*Math.PI/5;float rr=(i%2==0)?r:r*.42f;
            float px=x+(float)Math.cos(a)*rr, py=y+(float)Math.sin(a)*rr;
            if(i==0)path.moveTo(px,py);else path.lineTo(px,py);}
        path.close(); p.setColor(Color.rgb(255,231,110)); p.setShadowLayer(18,0,0,Color.rgb(255,220,70));
        setLayerType(View.LAYER_TYPE_SOFTWARE,p); c.drawPath(path,p); p.clearShadowLayer();
    }

    void drawShip(Canvas c,float x,float y) {
        Path path=new Path(); path.moveTo(x,y-28); path.lineTo(x-35,y+20); path.lineTo(x-12,y+14);
        path.lineTo(x,y+29); path.lineTo(x+12,y+14); path.lineTo(x+35,y+20); path.close();
        p.setColor(Color.rgb(225,240,255)); p.setShadowLayer(20,0,0,Color.rgb(60,190,255)); c.drawPath(path,p); p.clearShadowLayer();
        p.setColor(Color.rgb(80,205,255)); c.drawCircle(x,y-6,9,p);
        p.setColor(Color.rgb(255,145,55)); Path flame=new Path(); flame.moveTo(x-7,y+16); flame.lineTo(x,y+37+rnd.nextInt(8)); flame.lineTo(x+7,y+16); flame.close(); c.drawPath(flame,p);
    }

    void update() {
        long now=System.currentTimeMillis(); float dt=Math.min(.04f,(now-last)/1000f); last=now;
        spawnTimer+=dt*1000;
        if(spawnTimer>Math.max(280,850-score*4)){spawnTimer=0;stars.add(new Star(25+rnd.nextFloat()*(getWidth()-50),-20,9+rnd.nextFloat()*7,130+rnd.nextFloat()*100+score*2));}
        for(int i=stars.size()-1;i>=0;i--){
            Star s=stars.get(i); s.y+=s.v*dt;
            if(Math.hypot(s.x-shipX,s.y-shipY)<s.r+28){score++;burst(s.x,s.y);stars.remove(i);beep(700);vibrate(8);continue;}
            if(s.y>getHeight()+25){stars.remove(i);lives--;vibrate(35);if(lives<=0){finish();return;}}
        }
        for(int i=sparks.size()-1;i>=0;i--){Spark s=sparks.get(i);s.x+=s.vx*dt;s.y+=s.vy*dt;s.vy+=120*dt;s.life-=dt*1.7f;if(s.life<=0)sparks.remove(i);}
    }

    void burst(float x,float y){for(int i=0;i<16;i++){double a=rnd.nextDouble()*Math.PI*2;float v=60+rnd.nextFloat()*170;sparks.add(new Spark(x,y,(float)Math.cos(a)*v,(float)Math.sin(a)*v));}}

    @Override public boolean onTouchEvent(MotionEvent e) {
        if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE) {
            if(playing){shipX=Math.max(42,Math.min(getWidth()-42,e.getX()));shipY=getHeight()-75;}
            else if(e.getAction()==MotionEvent.ACTION_DOWN && e.getY()>getHeight()/2-10 && e.getY()<getHeight()/2+100) startGame();
            invalidate(); return true;
        } return true;
    }

    @Override public void onSizeChanged(int w,int h,int ow,int oh){shipX=w/2f;shipY=h-75;}
    @Override protected void onAttachedToWindow(){super.onAttachedToWindow();postInvalidate();}
}
